import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:ecoledger/models/user_model.dart';
import 'package:ecoledger/services/blockchain_service.dart';

class UserService {
  static const String _userKey = 'current_user';
  final BlockchainService _blockchainService = BlockchainService();

  Future<UserModel> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userJson = prefs.getString(_userKey);
    
    if (userJson != null) {
      return UserModel.fromJson(jsonDecode(userJson));
    }
    
    final walletAddress = await _blockchainService.generateWalletAddress();
    final newUser = UserModel(
      id: const Uuid().v4(),
      name: 'Carbon Tracker',
      email: 'user@ecoledger.com',
      walletAddress: walletAddress,
      totalEmissions: 0.0,
      totalCredits: 0.0,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    
    await _saveUser(newUser);
    return newUser;
  }

  Future<void> updateUser(UserModel user) async {
    final updatedUser = user.copyWith(updatedAt: DateTime.now());
    await _saveUser(updatedUser);
  }

  Future<void> updateUserBalance(double emissions, double credits) async {
    final user = await getCurrentUser();
    final updatedUser = user.copyWith(
      totalEmissions: user.totalEmissions + emissions,
      totalCredits: user.totalCredits + credits,
      updatedAt: DateTime.now(),
    );
    await _saveUser(updatedUser);
  }

  Future<void> _saveUser(UserModel user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userKey, jsonEncode(user.toJson()));
  }
}
