import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:ecoledger/models/transaction_model.dart';

// Conditional import: uses web saver on web, clipboard stub elsewhere
import 'package:ecoledger/utils/save_helper_stub.dart'
    if (dart.library.html) 'package:ecoledger/utils/save_helper_web.dart' as saver;

class ExportService {
  String _escapeCsvField(String value) {
    var v = value;
    if (v.contains('"')) {
      v = v.replaceAll('"', '""');
    }
    if (v.contains(',') || v.contains('\n') || v.contains('"')) {
      return '"$v"';
    }
    return v;
  }

  String _formatDate(DateTime dt) => dt.toIso8601String();

  String buildTransactionsCsv(List<TransactionModel> items) {
    final headers = [
      'id',
      'userId',
      'type',
      'amount',
      'category',
      'description',
      'blockchainHash',
      'blockNumber',
      'timestamp',
      'status',
      'createdAt',
      'updatedAt',
    ];

    final rows = <String>[];
    rows.add(headers.join(','));

    for (final t in items) {
      final row = [
        _escapeCsvField(t.id),
        _escapeCsvField(t.userId),
        _escapeCsvField(t.type.name),
        _escapeCsvField(t.amount.toStringAsFixed(2)),
        _escapeCsvField(t.category),
        _escapeCsvField(t.description),
        _escapeCsvField(t.blockchainHash),
        _escapeCsvField(t.blockNumber.toString()),
        _escapeCsvField(_formatDate(t.timestamp)),
        _escapeCsvField(t.status.name),
        _escapeCsvField(_formatDate(t.createdAt)),
        _escapeCsvField(_formatDate(t.updatedAt)),
      ].join(',');
      rows.add(row);
    }

    return rows.join('\n');
  }

  String buildStatisticsCsv({
    required Map<String, double> summary,
    required Map<String, double> monthly,
  }) {
    final lines = <String>[];
    // Summary block
    lines.add('section,key,value');
    for (final entry in summary.entries) {
      final key = _escapeCsvField(entry.key);
      final value = _escapeCsvField(entry.value.toStringAsFixed(2));
      lines.add('summary,$key,$value');
    }

    // Blank line between sections is fine for CSV readers
    lines.add('');

    // Monthly block
    lines.add('section,month,net');
    // Keep months in the provided order
    for (final entry in monthly.entries) {
      final month = _escapeCsvField(entry.key);
      final net = _escapeCsvField(entry.value.toStringAsFixed(2));
      lines.add('monthly,$month,$net');
    }

    return lines.join('\n');
  }

  Future<void> saveCsv(BuildContext context, String baseName, String csv) async {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    final ts = '${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}${two(now.second)}';
    final filename = '${baseName}_$ts.csv';

    final ok = await saver.saveCsv(filename, csv);

    if (!context.mounted) return;

    final theme = Theme.of(context);
    final messenger = ScaffoldMessenger.of(context);

    if (ok) {
      messenger.showSnackBar(
        SnackBar(
          content: Text(kIsWeb
              ? 'CSV downloaded: $filename'
              : 'CSV copied to clipboard'),
          backgroundColor: theme.colorScheme.primary,
        ),
      );
    } else {
      messenger.showSnackBar(
        SnackBar(
          content: const Text('Failed to export CSV'),
          backgroundColor: theme.colorScheme.error,
        ),
      );
    }
  }
}
