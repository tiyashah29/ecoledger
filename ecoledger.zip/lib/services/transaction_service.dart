import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:ecoledger/models/transaction_model.dart';
import 'package:ecoledger/services/blockchain_service.dart';
import 'package:ecoledger/services/user_service.dart';

class TransactionService {
  static const String _transactionsKey = 'transactions';
  final BlockchainService _blockchainService = BlockchainService();
  final UserService _userService = UserService();

  Future<List<TransactionModel>> getAllTransactions() async {
    final prefs = await SharedPreferences.getInstance();
    final transactionsJson = prefs.getStringList(_transactionsKey) ?? [];
    return transactionsJson.map((json) => TransactionModel.fromJson(jsonDecode(json))).toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  Future<TransactionModel?> getTransactionById(String id) async {
    final transactions = await getAllTransactions();
    try {
      return transactions.firstWhere((t) => t.id == id);
    } catch (e) {
      return null;
    }
  }

  Future<TransactionModel> addTransaction(TransactionModel transaction) async {
    final prefs = await SharedPreferences.getInstance();
    final transactionsJson = prefs.getStringList(_transactionsKey) ?? [];
    
    final user = await _userService.getCurrentUser();
    
    final newTransaction = transaction.copyWith(
      id: const Uuid().v4(),
      userId: user.id,
      status: TransactionStatus.pending,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    
    final hash = await _blockchainService.submitToBlockchain(newTransaction);
    final record = await _blockchainService.getBlockchainRecord(hash);
    
    final confirmedTransaction = newTransaction.copyWith(
      blockchainHash: hash,
      blockNumber: record?.blockNumber ?? 0,
      status: TransactionStatus.confirmed,
    );
    
    transactionsJson.add(jsonEncode(confirmedTransaction.toJson()));
    await prefs.setStringList(_transactionsKey, transactionsJson);
    
    if (confirmedTransaction.type == TransactionType.emission) {
      await _userService.updateUserBalance(confirmedTransaction.amount, 0);
    } else {
      await _userService.updateUserBalance(0, confirmedTransaction.amount);
    }
    
    return confirmedTransaction;
  }

  Future<List<TransactionModel>> getTransactionsByType(TransactionType type) async {
    final transactions = await getAllTransactions();
    return transactions.where((t) => t.type == type).toList();
  }

  Future<Map<String, double>> getStatistics() async {
    final transactions = await getAllTransactions();
    
    double totalEmissions = 0;
    double totalCredits = 0;
    
    for (final transaction in transactions) {
      if (transaction.type == TransactionType.emission) {
        totalEmissions += transaction.amount;
      } else {
        totalCredits += transaction.amount;
      }
    }
    
    return {
      'totalEmissions': totalEmissions,
      'totalCredits': totalCredits,
      'netBalance': totalCredits - totalEmissions,
      'transactionCount': transactions.length.toDouble(),
    };
  }

  Future<Map<String, double>> getMonthlyData() async {
    final transactions = await getAllTransactions();
    final now = DateTime.now();
    final last6Months = <String, double>{};
    
    for (int i = 5; i >= 0; i--) {
      final month = DateTime(now.year, now.month - i, 1);
      final monthKey = '${month.month.toString().padLeft(2, '0')}/${month.year}';
      last6Months[monthKey] = 0;
    }
    
    for (final transaction in transactions) {
      final monthKey = '${transaction.timestamp.month.toString().padLeft(2, '0')}/${transaction.timestamp.year}';
      if (last6Months.containsKey(monthKey)) {
        final amount = transaction.type == TransactionType.emission 
          ? transaction.amount 
          : -transaction.amount;
        last6Months[monthKey] = (last6Months[monthKey] ?? 0) + amount;
      }
    }
    
    return last6Months;
  }
}
