import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ecoledger/models/blockchain_record_model.dart';
import 'package:ecoledger/models/transaction_model.dart';

class BlockchainService {
  static const String _blockchainKey = 'blockchain_data';
  static const String _blockCountKey = 'block_count';
  static const String _walletKey = 'wallet_address';
  static const String _contractAddress = '0xCarbonCreditContract2024';

  Future<String> submitToBlockchain(TransactionModel transaction) async {
    final prefs = await SharedPreferences.getInstance();
    
    final blockNumber = await _getNextBlockNumber();
    final previousHash = await _getLastBlockHash();
    final timestamp = DateTime.now();
    
    final blockData = {
      'blockNumber': blockNumber,
      'previousHash': previousHash,
      'timestamp': timestamp.toIso8601String(),
      'transactionId': transaction.id,
      'type': transaction.type.name,
      'amount': transaction.amount,
      'category': transaction.category,
      'from': await getCurrentWalletAddress(),
      'to': _contractAddress,
    };
    
    final hash = _generateHash(jsonEncode(blockData));
    
    final record = BlockchainRecordModel(
      transactionHash: hash,
      blockNumber: blockNumber,
      fromAddress: await getCurrentWalletAddress(),
      toAddress: _contractAddress,
      amount: transaction.amount,
      gasUsed: Random().nextInt(50000) + 21000,
      timestamp: timestamp,
      confirmations: 1,
    );
    
    await _saveBlockchainRecord(record);
    
    return hash;
  }

  Future<BlockchainRecordModel?> getBlockchainRecord(String hash) async {
    final prefs = await SharedPreferences.getInstance();
    final blockchainData = prefs.getStringList(_blockchainKey) ?? [];
    
    for (final recordJson in blockchainData) {
      final record = BlockchainRecordModel.fromJson(jsonDecode(recordJson));
      if (record.transactionHash == hash) {
        return record;
      }
    }
    return null;
  }

  Future<bool> verifyTransaction(String hash) async {
    final record = await getBlockchainRecord(hash);
    return record != null && record.confirmations > 0;
  }

  Future<String> generateWalletAddress() async {
    final random = Random.secure();
    final bytes = List<int>.generate(20, (_) => random.nextInt(256));
    final address = '0x${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}';
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_walletKey, address);
    
    return address;
  }

  Future<String> getCurrentWalletAddress() async {
    final prefs = await SharedPreferences.getInstance();
    String? address = prefs.getString(_walletKey);
    
    if (address == null) {
      address = await generateWalletAddress();
    }
    
    return address;
  }

  String _generateHash(String data) {
    final bytes = utf8.encode(data);
    final digest = sha256.convert(bytes);
    return '0x${digest.toString()}';
  }

  Future<int> _getNextBlockNumber() async {
    final prefs = await SharedPreferences.getInstance();
    final currentBlock = prefs.getInt(_blockCountKey) ?? 0;
    final nextBlock = currentBlock + 1;
    await prefs.setInt(_blockCountKey, nextBlock);
    return nextBlock;
  }

  Future<String> _getLastBlockHash() async {
    final prefs = await SharedPreferences.getInstance();
    final blockchainData = prefs.getStringList(_blockchainKey) ?? [];
    
    if (blockchainData.isEmpty) {
      return '0x0000000000000000000000000000000000000000000000000000000000000000';
    }
    
    final lastRecord = BlockchainRecordModel.fromJson(jsonDecode(blockchainData.last));
    return lastRecord.transactionHash;
  }

  Future<void> _saveBlockchainRecord(BlockchainRecordModel record) async {
    final prefs = await SharedPreferences.getInstance();
    final blockchainData = prefs.getStringList(_blockchainKey) ?? [];
    blockchainData.add(jsonEncode(record.toJson()));
    await prefs.setStringList(_blockchainKey, blockchainData);
  }

  Future<List<BlockchainRecordModel>> getAllBlockchainRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final blockchainData = prefs.getStringList(_blockchainKey) ?? [];
    return blockchainData.map((json) => BlockchainRecordModel.fromJson(jsonDecode(json))).toList();
  }
}
