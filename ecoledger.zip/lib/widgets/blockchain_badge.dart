import 'package:flutter/material.dart';
import 'package:ecoledger/models/transaction_model.dart';

class BlockchainBadge extends StatelessWidget {
  final TransactionStatus status;

  const BlockchainBadge({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    Color color;
    IconData icon;
    String label;
    
    switch (status) {
      case TransactionStatus.confirmed:
        color = theme.colorScheme.tertiary;
        icon = Icons.verified;
        label = 'Confirmed';
        break;
      case TransactionStatus.pending:
        color = const Color(0xFFFFA726);
        icon = Icons.hourglass_empty;
        label = 'Pending';
        break;
      case TransactionStatus.failed:
        color = theme.colorScheme.error;
        icon = Icons.error_outline;
        label = 'Failed';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
