import 'package:flutter/services.dart';

// Fallback save helper for non-web platforms.
// Copies CSV content to clipboard as a basic export option.
Future<bool> saveCsv(String filename, String csv) async {
  try {
    await Clipboard.setData(ClipboardData(text: csv));
    return true;
  } catch (_) {
    return false;
  }
}
