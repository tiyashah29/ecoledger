enum TransactionType { emission, credit }
enum TransactionStatus { pending, confirmed, failed }

class TransactionModel {
  final String id;
  final String userId;
  final TransactionType type;
  final double amount;
  final String category;
  final String description;
  final String blockchainHash;
  final int blockNumber;
  final DateTime timestamp;
  final TransactionStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;

  TransactionModel({
    required this.id,
    required this.userId,
    required this.type,
    required this.amount,
    required this.category,
    required this.description,
    required this.blockchainHash,
    required this.blockNumber,
    required this.timestamp,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'userId': userId,
    'type': type.name,
    'amount': amount,
    'category': category,
    'description': description,
    'blockchainHash': blockchainHash,
    'blockNumber': blockNumber,
    'timestamp': timestamp.toIso8601String(),
    'status': status.name,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory TransactionModel.fromJson(Map<String, dynamic> json) => TransactionModel(
    id: json['id'] as String,
    userId: json['userId'] as String,
    type: TransactionType.values.firstWhere((e) => e.name == json['type']),
    amount: (json['amount'] as num).toDouble(),
    category: json['category'] as String,
    description: json['description'] as String,
    blockchainHash: json['blockchainHash'] as String,
    blockNumber: json['blockNumber'] as int,
    timestamp: DateTime.parse(json['timestamp'] as String),
    status: TransactionStatus.values.firstWhere((e) => e.name == json['status']),
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
  );

  TransactionModel copyWith({
    String? id,
    String? userId,
    TransactionType? type,
    double? amount,
    String? category,
    String? description,
    String? blockchainHash,
    int? blockNumber,
    DateTime? timestamp,
    TransactionStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => TransactionModel(
    id: id ?? this.id,
    userId: userId ?? this.userId,
    type: type ?? this.type,
    amount: amount ?? this.amount,
    category: category ?? this.category,
    description: description ?? this.description,
    blockchainHash: blockchainHash ?? this.blockchainHash,
    blockNumber: blockNumber ?? this.blockNumber,
    timestamp: timestamp ?? this.timestamp,
    status: status ?? this.status,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
