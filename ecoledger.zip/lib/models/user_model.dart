class UserModel {
  final String id;
  final String name;
  final String email;
  final String walletAddress;
  final double totalEmissions;
  final double totalCredits;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.walletAddress,
    required this.totalEmissions,
    required this.totalCredits,
    required this.createdAt,
    required this.updatedAt,
  });

  double get netBalance => totalCredits - totalEmissions;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'email': email,
    'walletAddress': walletAddress,
    'totalEmissions': totalEmissions,
    'totalCredits': totalCredits,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    id: json['id'] as String,
    name: json['name'] as String,
    email: json['email'] as String,
    walletAddress: json['walletAddress'] as String,
    totalEmissions: (json['totalEmissions'] as num).toDouble(),
    totalCredits: (json['totalCredits'] as num).toDouble(),
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
  );

  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? walletAddress,
    double? totalEmissions,
    double? totalCredits,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => UserModel(
    id: id ?? this.id,
    name: name ?? this.name,
    email: email ?? this.email,
    walletAddress: walletAddress ?? this.walletAddress,
    totalEmissions: totalEmissions ?? this.totalEmissions,
    totalCredits: totalCredits ?? this.totalCredits,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
}
