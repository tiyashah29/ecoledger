class BlockchainRecordModel {
  final String transactionHash;
  final int blockNumber;
  final String fromAddress;
  final String toAddress;
  final double amount;
  final int gasUsed;
  final DateTime timestamp;
  final int confirmations;

  BlockchainRecordModel({
    required this.transactionHash,
    required this.blockNumber,
    required this.fromAddress,
    required this.toAddress,
    required this.amount,
    required this.gasUsed,
    required this.timestamp,
    required this.confirmations,
  });

  Map<String, dynamic> toJson() => {
    'transactionHash': transactionHash,
    'blockNumber': blockNumber,
    'fromAddress': fromAddress,
    'toAddress': toAddress,
    'amount': amount,
    'gasUsed': gasUsed,
    'timestamp': timestamp.toIso8601String(),
    'confirmations': confirmations,
  };

  factory BlockchainRecordModel.fromJson(Map<String, dynamic> json) => BlockchainRecordModel(
    transactionHash: json['transactionHash'] as String,
    blockNumber: json['blockNumber'] as int,
    fromAddress: json['fromAddress'] as String,
    toAddress: json['toAddress'] as String,
    amount: (json['amount'] as num).toDouble(),
    gasUsed: json['gasUsed'] as int,
    timestamp: DateTime.parse(json['timestamp'] as String),
    confirmations: json['confirmations'] as int,
  );

  BlockchainRecordModel copyWith({
    String? transactionHash,
    int? blockNumber,
    String? fromAddress,
    String? toAddress,
    double? amount,
    int? gasUsed,
    DateTime? timestamp,
    int? confirmations,
  }) => BlockchainRecordModel(
    transactionHash: transactionHash ?? this.transactionHash,
    blockNumber: blockNumber ?? this.blockNumber,
    fromAddress: fromAddress ?? this.fromAddress,
    toAddress: toAddress ?? this.toAddress,
    amount: amount ?? this.amount,
    gasUsed: gasUsed ?? this.gasUsed,
    timestamp: timestamp ?? this.timestamp,
    confirmations: confirmations ?? this.confirmations,
  );
}
