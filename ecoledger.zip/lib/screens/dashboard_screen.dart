import 'package:flutter/material.dart';
import 'package:ecoledger/models/transaction_model.dart';
import 'package:ecoledger/models/user_model.dart';
import 'package:ecoledger/services/transaction_service.dart';
import 'package:ecoledger/services/user_service.dart';
import 'package:ecoledger/widgets/stat_card.dart';
import 'package:ecoledger/widgets/transaction_card.dart';
import 'package:ecoledger/screens/transaction_detail_screen.dart';
import 'package:ecoledger/services/export_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final TransactionService _transactionService = TransactionService();
  final UserService _userService = UserService();
    final _exportService = ExportService();
  
  UserModel? _user;
  List<TransactionModel> _recentTransactions = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    final user = await _userService.getCurrentUser();
    final transactions = await _transactionService.getAllTransactions();
    
    setState(() {
      _user = user;
      _recentTransactions = transactions.take(5).toList();
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    
    return RefreshIndicator(
      onRefresh: _loadData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Carbon Overview',
              style: theme.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: Container()),
                FilledButton.icon(
                  onPressed: _exportStats,
                  icon: const Icon(Icons.download),
                  label: const Text('Export CSV'),
                ),
              ],
            ),
            const SizedBox(height: 24),
            StatCard(
              title: 'Total Emissions',
              value: _user!.totalEmissions.toStringAsFixed(2),
              unit: 'tons CO₂',
              icon: Icons.cloud,
              color: theme.colorScheme.error,
              subtitle: 'Impact',
            ),
            const SizedBox(height: 16),
            StatCard(
              title: 'Carbon Credits',
              value: _user!.totalCredits.toStringAsFixed(2),
              unit: 'credits',
              icon: Icons.eco,
              color: theme.colorScheme.tertiary,
              subtitle: 'Offset',
            ),
            const SizedBox(height: 16),
            StatCard(
              title: 'Net Balance',
              value: _user!.netBalance.abs().toStringAsFixed(2),
              unit: _user!.netBalance >= 0 ? 'surplus' : 'deficit',
              icon: _user!.netBalance >= 0 ? Icons.trending_up : Icons.trending_down,
              color: _user!.netBalance >= 0 ? theme.colorScheme.tertiary : theme.colorScheme.error,
              subtitle: 'Status',
            ),
            const SizedBox(height: 32),
            Row(
              children: [
                Text(
                  'Recent Activity',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.lock,
                        size: 14,
                        color: theme.colorScheme.primary,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Blockchain',
                        style: theme.textTheme.labelSmall?.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (_recentTransactions.isEmpty)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(48),
                  child: Column(
                    children: [
                      Icon(
                        Icons.receipt_long,
                        size: 64,
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'No transactions yet',
                        style: theme.textTheme.bodyLarge?.copyWith(
                          color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              ..._recentTransactions.map((transaction) => TransactionCard(
                transaction: transaction,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TransactionDetailScreen(
                        transactionId: transaction.id,
                      ),
                    ),
                  );
                },
              )),
          ],
        ),
      ),
    );
  }
}

extension on _DashboardScreenState {
  Future<void> _exportStats() async {
    final summary = await _transactionService.getStatistics();
    final monthly = await _transactionService.getMonthlyData();
    final csv = _exportService.buildStatisticsCsv(summary: summary, monthly: monthly);
    await _exportService.saveCsv(context, 'statistics', csv);
  }
}
