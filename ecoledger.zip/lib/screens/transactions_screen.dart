import 'package:flutter/material.dart';
import 'package:ecoledger/models/transaction_model.dart';
import 'package:ecoledger/services/transaction_service.dart';
import 'package:ecoledger/services/export_service.dart';
import 'package:ecoledger/widgets/transaction_card.dart';
import 'package:ecoledger/screens/transaction_detail_screen.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key});

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final TransactionService _transactionService = TransactionService();
    final _exportService = ExportService();
  
  List<TransactionModel> _transactions = [];
  List<TransactionModel> _filteredTransactions = [];
  bool _isLoading = true;
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _loadTransactions();
  }

  Future<void> _loadTransactions() async {
    setState(() => _isLoading = true);
    
    final transactions = await _transactionService.getAllTransactions();
    
    setState(() {
      _transactions = transactions;
      _applyFilter();
      _isLoading = false;
    });
  }

  void _applyFilter() {
    if (_filter == 'all') {
      _filteredTransactions = _transactions;
    } else if (_filter == 'emissions') {
      _filteredTransactions = _transactions.where((t) => t.type == TransactionType.emission).toList();
    } else {
      _filteredTransactions = _transactions.where((t) => t.type == TransactionType.credit).toList();
    }
  }

  Future<void> _exportTransactions() async {
    final csv = _exportService.buildTransactionsCsv(_filteredTransactions);
    await _exportService.saveCsv(context, 'transactions', csv);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'All Transactions',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Export CSV',
                      onPressed: _exportTransactions,
                      icon: const Icon(Icons.download),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _FilterChip(
                        label: 'All',
                        isSelected: _filter == 'all',
                        onTap: () {
                          setState(() {
                            _filter = 'all';
                            _applyFilter();
                          });
                        },
                      ),
                      const SizedBox(width: 12),
                      _FilterChip(
                        label: 'Emissions',
                        isSelected: _filter == 'emissions',
                        onTap: () {
                          setState(() {
                            _filter = 'emissions';
                            _applyFilter();
                          });
                        },
                      ),
                      const SizedBox(width: 12),
                      _FilterChip(
                        label: 'Credits',
                        isSelected: _filter == 'credits',
                        onTap: () {
                          setState(() {
                            _filter = 'credits';
                            _applyFilter();
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _filteredTransactions.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.receipt_long,
                          size: 80,
                          color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No transactions found',
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
                          ),
                        ),
                      ],
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _loadTransactions,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                      itemCount: _filteredTransactions.length,
                      itemBuilder: (context, index) {
                        final transaction = _filteredTransactions[index];
                        return TransactionCard(
                          transaction: transaction,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => TransactionDetailScreen(
                                  transactionId: transaction.id,
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected 
            ? theme.colorScheme.primary 
            : theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: isSelected 
              ? theme.colorScheme.primary 
              : theme.colorScheme.onSurface.withValues(alpha: 0.2),
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          style: theme.textTheme.labelLarge?.copyWith(
            color: isSelected 
              ? Colors.white 
              : theme.colorScheme.onSurface,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
