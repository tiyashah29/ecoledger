import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:ecoledger/models/transaction_model.dart';
import 'package:ecoledger/models/blockchain_record_model.dart';
import 'package:ecoledger/services/transaction_service.dart';
import 'package:ecoledger/services/blockchain_service.dart';
import 'package:ecoledger/widgets/blockchain_badge.dart';

class TransactionDetailScreen extends StatefulWidget {
  final String transactionId;

  const TransactionDetailScreen({super.key, required this.transactionId});

  @override
  State<TransactionDetailScreen> createState() => _TransactionDetailScreenState();
}

class _TransactionDetailScreenState extends State<TransactionDetailScreen> {
  final TransactionService _transactionService = TransactionService();
  final BlockchainService _blockchainService = BlockchainService();
  
  TransactionModel? _transaction;
  BlockchainRecordModel? _blockchainRecord;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    final transaction = await _transactionService.getTransactionById(widget.transactionId);
    
    if (transaction != null) {
      final record = await _blockchainService.getBlockchainRecord(transaction.blockchainHash);
      
      setState(() {
        _transaction = transaction;
        _blockchainRecord = record;
        _isLoading = false;
      });
    } else {
      setState(() => _isLoading = false);
    }
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$label copied to clipboard')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Transaction Details'),
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    
    if (_transaction == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Transaction Details'),
        ),
        body: const Center(child: Text('Transaction not found')),
      );
    }
    
    final isEmission = _transaction!.type == TransactionType.emission;
    final color = isEmission ? theme.colorScheme.error : theme.colorScheme.tertiary;
    
    return Scaffold(
      backgroundColor: theme.colorScheme.surface,
      appBar: AppBar(
        title: Text(
          'Transaction Details',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    color.withValues(alpha: 0.2),
                    color.withValues(alpha: 0.05),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  Icon(
                    isEmission ? Icons.cloud : Icons.eco,
                    size: 64,
                    color: color,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    '${isEmission ? '+' : '-'}${_transaction!.amount.toStringAsFixed(2)}',
                    style: theme.textTheme.displaySmall?.copyWith(
                      color: color,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    isEmission ? 'tons CO₂' : 'credits',
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                  ),
                  const SizedBox(height: 16),
                  BlockchainBadge(status: _transaction!.status),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Text(
              'Transaction Information',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _InfoTile(
              label: 'Type',
              value: isEmission ? 'Carbon Emission' : 'Carbon Credit',
              icon: Icons.label,
            ),
            _InfoTile(
              label: 'Category',
              value: _transaction!.category,
              icon: Icons.category,
            ),
            if (_transaction!.description.isNotEmpty)
              _InfoTile(
                label: 'Description',
                value: _transaction!.description,
                icon: Icons.notes,
              ),
            _InfoTile(
              label: 'Date & Time',
              value: DateFormat('MMM dd, yyyy • HH:mm:ss').format(_transaction!.timestamp),
              icon: Icons.access_time,
            ),
            const SizedBox(height: 32),
            Text(
              'Blockchain Verification',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            _InfoTile(
              label: 'Transaction Hash',
              value: _transaction!.blockchainHash,
              icon: Icons.fingerprint,
              isCopyable: true,
              onCopy: () => _copyToClipboard(_transaction!.blockchainHash, 'Hash'),
            ),
            _InfoTile(
              label: 'Block Number',
              value: '#${_transaction!.blockNumber}',
              icon: Icons.tag,
            ),
            if (_blockchainRecord != null) ...[
              _InfoTile(
                label: 'From Address',
                value: _blockchainRecord!.fromAddress,
                icon: Icons.account_balance_wallet,
                isCopyable: true,
                onCopy: () => _copyToClipboard(_blockchainRecord!.fromAddress, 'Address'),
              ),
              _InfoTile(
                label: 'Gas Used',
                value: '${_blockchainRecord!.gasUsed} units',
                icon: Icons.local_gas_station,
              ),
              _InfoTile(
                label: 'Confirmations',
                value: '${_blockchainRecord!.confirmations}',
                icon: Icons.check_circle,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final bool isCopyable;
  final VoidCallback? onCopy;

  const _InfoTile({
    required this.label,
    required this.value,
    required this.icon,
    this.isCopyable = false,
    this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.onSurface.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: theme.colorScheme.primary, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: isCopyable ? null : 2,
                  overflow: isCopyable ? null : TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (isCopyable) ...[
            const SizedBox(width: 8),
            IconButton(
              icon: Icon(Icons.copy, size: 18, color: theme.colorScheme.primary),
              onPressed: onCopy,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ],
      ),
    );
  }
}
